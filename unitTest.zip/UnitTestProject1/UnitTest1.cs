﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestProject1;
using System;
using Example;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestNumberStrength()
        {// arrange
            string password = "89345671223";
            int expected = 1;
            // act
            int actual = Class1.GetNumberStrength(password);
            // assert
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void TestNumberStrengtNeg()
        {// arrange
            string password = "8934567122";
            int expected = 0;
            // act
            int actual = Class1.GetNumberStrength(password);
            // assert
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void TestNumberLetter()
        {// arrange
            string password = "8934567234s";
            int expected = 1;
            // act
            int actual = Class1.GetNumberStrength(password);
            // assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestNameNumber()
        {// arrange
            string name = "Michae1";
            int expected = 1;
            // act
            int actual = Class1.GetNameNumber(name);
            // assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TesNumberMinus()
        {// arrange
            double weight = -2.6;
            int expected = 0;
            // act
            int actual = Class1.GetNumberMinus(weight);
            // assert
            Assert.AreEqual(expected, actual);
        }
    }
}
