﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Example
{
    public static class Class1
    {
        public static int GetNumberStrength(string phone)
        {        
            int result = 0;
            if (phone.Length == 11)
            {
                result++;
            }     
            return result;
        }
        public static int GetNumberLetter(string phone)
        {
            int result = 0;
            if (Regex.Match(phone, "[a-z]").Success)
            {
                result++;
            }
            return result;
        }
        public static int GetNameNumber(string name)
        {
            int result = 0;
            if (Regex.Match(name, "[0-9]").Success)
            {
                result++;
            }
            return result;
        }
        public static int GetNumberMinus(double weight)
        {
            int result = 0;
            if (weight>0)
            {
                result++;
            }
            return result;
        }
    }
}
