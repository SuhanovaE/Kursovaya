﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageClients.xaml
    /// </summary>
    public partial class AddEditPageClients : Page
    {
        private Clients _currentClients = new Clients();
        public AddEditPageClients(Clients selectedClients)
        {
            InitializeComponent();
            if (selectedClients != null)
                _currentClients = selectedClients;
            //создаем контекст
            DataContext = _currentClients;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке
            if (string.IsNullOrWhiteSpace(_currentClients.lastname))
                error.AppendLine("Укажите фамилию");
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentClients.firstname))
                error.AppendLine("Укажите имя");
            if (string.IsNullOrWhiteSpace(_currentClients.patronymic))
                error.AppendLine("Укажите отчество");
            if (_currentClients.phone.Length != 11)
                error.AppendLine("Номер телефона должен содержать 11 цифр");
            if (_currentClients.phone==null)
                error.AppendLine("Укажите номер телефона");
          
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentClients.id_clients==0)
            {
                JewelryShopEntities.GetContext().Clients.Add(_currentClients);
            }
            try
            {
                JewelryShopEntities.GetContext().SaveChanges();
                MessageBox.Show("Клиент добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
