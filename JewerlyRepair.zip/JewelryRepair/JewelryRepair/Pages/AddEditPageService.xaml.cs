﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageService.xaml
    /// </summary>
    public partial class AddEditPageService : Page
    {
        private Service _currentService = new Service();
        public AddEditPageService(Service selectedService)
        {
            InitializeComponent();
            if (selectedService != null)
                _currentService = selectedService;
            //создаем контекст
            DataContext = _currentService;

        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentService.name))
                error.AppendLine("Укажите название услуги");
           
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentService.id_service == 0)
                JewelryShopEntities.GetContext().Service.Add(_currentService); //добавить в контекст
            try
            {
                JewelryShopEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новая услуга добавлена");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
