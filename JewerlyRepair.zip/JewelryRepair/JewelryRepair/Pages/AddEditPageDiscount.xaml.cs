﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JewelryRepair
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageDiscount.xaml
    /// </summary>
    public partial class AddEditPageDiscount : Page
    {
        private Discount _currentDiscount = new Discount();
        public AddEditPageDiscount(Discount selectedDiscount)
        {
            InitializeComponent();
            if (selectedDiscount != null)
                _currentDiscount = selectedDiscount;
            //создаем контекст
            DataContext = _currentDiscount;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (_currentDiscount.discount1<0)
                error.AppendLine("Размер скидки не может быть отрицательной");            
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }         
            if (_currentDiscount.id_discount == 0)
            {
                JewelryShopEntities.GetContext().Discount.Add(_currentDiscount);
            }
            try
            {
                JewelryShopEntities.GetContext().SaveChanges();
                MessageBox.Show("Запись добавлена");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
